# LexBridge — private portfolio starter (v0.1)

A simple, accessible, multilingual (EN/DE/FR) legal operations workspace. **No model is connected; no legal review happens yet.** The backend intentionally does not store submitted matter text. **Do not use real client documents.**

## Start in GitHub Codespaces / Linux / macOS
Open two terminals from the repository root.

**Terminal A (API)**
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

**Terminal B (UI)**
```bash
cd frontend
npm install
npm run dev
```

Open the forwarded **port 5173** in Codespaces (use private port visibility). Port 8000 should also remain private. The Vite dev server proxies `/api` to port 8000.

## Real limitations
- This is a UI/API scaffold, **not** an AI agent or legal advisory service.
- No authenticating users yet. **Do not publish/deploy a public instance** until auth, rate limiting, secure storage and security review are added.
- Matter text is sent to the local API process but not stored; don't paste confidential data.
- Switzerland is represented only as a manifest. No Fedlex content has been ingested.
- Jurisdiction addition = a new `backend/jurisdictions/<id>/manifest.json`; verified legal support requires source ingestion, playbooks and tests.
- Future agent-to-agent discussions should use a structured event log (messages, model id, evidence citations, review status), not autonomous unlimited conversation.

## Planned milestones
1. Local source ingestion & versioned Swiss law data (Fedlex; verify language/validity)
2. Evidence-based legal research (source excerpts, exact citations, date validity)
3. Review of pasted text + company playbook + human approval
4. Replaceable AI provider interface
5. DOCX and digitally generated PDF ingestion
6. Secure invite-only demo with access control
