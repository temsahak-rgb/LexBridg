from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Literal
from uuid import uuid4
from pathlib import Path
import json

app = FastAPI(title="LexBridge API", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"], allow_credentials=False, allow_methods=["GET", "POST"], allow_headers=["*"])
ROOT = Path(__file__).resolve().parents[1]

class MatterIn(BaseModel):
    title: str = Field(min_length=2, max_length=120)
    text: str = Field(min_length=10, max_length=30000)
    jurisdiction: str = "ch"
    language: Literal["en", "de", "fr"] = "en"
    kind: Literal["contract", "corporate", "compliance"] = "contract"

class MatterOut(BaseModel):
    id: str
    title: str
    status: str
    jurisdiction: str
    warnings: list[str]
    analysis: str

@app.get('/api/health')
def health():
    return {"ok": True, "ai_connected": False, "mode": "local scaffold"}

@app.get('/api/jurisdictions')
def jurisdictions():
    result = []
    for p in sorted((ROOT / 'jurisdictions').glob('*/manifest.json')):
        result.append(json.loads(p.read_text(encoding='utf-8')))
    return result

@app.post('/api/matters', response_model=MatterOut)
def create_matter(matter: MatterIn):
    # No legal analysis occurs in v0.1. Data are NOT persisted.
    return MatterOut(id=str(uuid4()), title=matter.title, jurisdiction=matter.jurisdiction,
        status="awaiting-human-review", warnings=["No AI connected", "No legal source verified", "Do not use for legal decisions"],
        analysis="Draft workspace created. Contract review, citation checks and agent collaboration are not implemented yet.")
